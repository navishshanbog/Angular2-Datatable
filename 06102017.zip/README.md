# resite
Complete site built on require and react.

## Installing Dependencies
npm install

## Starting the server
npm run start

## Building with a particular config (the below is an example with mock)
npm run build -- --config=webpack.config.mock.js

or

npm run build-watch -- --config=webpack.config.mock.js

# allow chromedriver to install for tests
SET CHROMEDRIVER_CDNURL=http://diacnexus.immi.gov.au/cloud-mirror/chromedriver/

or

export CHROMEDRIVER_CDNURL=http://diacnexus.immi.gov.au/cloud-mirror/chromedriver/

# node sass environment variable
SET SASS_BINARY_SITE=http://diacnexus.immi.gov.au/cloud-mirror/node-sass

or

export SASS_BINARY_SITE=http://diacnexus.immi.gov.au/cloud-mirror/node-sass

#
