const webpack = require("webpack");
const webpackBaseConfig = require("./webpack.config.base");

// NOTE: this is 'dev'

const webpackDevConfig = Object.assign({}, webpackBaseConfig);

const publicPath = "/analystdesktop/widget/site/";
webpackDevConfig.output.publicPath = publicPath;

webpackDevConfig.plugins.push(
    new webpack.DefinePlugin({
        "process.env.NODE_ENV": JSON.stringify("development"),
        "AppConfig": JSON.stringify({
            production: false,
            basePath: publicPath,
            buildVersion: 'DEV',
            buildDate: new Date()
        })
    })
);

module.exports = webpackDevConfig;