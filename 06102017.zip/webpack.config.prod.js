const webpack = require("webpack");
const webpackConfigBase = require("./webpack.config.base.js");

const webpackProdConfig = Object.assign({}, webpackConfigBase);

const publicPath = "/analystdesktop/widget/site/";

webpackProdConfig.output.filename = "[name].[chunkhash].js";
webpackProdConfig.output.publicPath = publicPath;
webpackProdConfig.plugins.push(
    new webpack.optimize.UglifyJsPlugin({
        sourceMap: webpackConfigBase.devtool === "source-map"
    })
);

module.exports = function(env) {
    webpackProdConfig.plugins.push(
        new webpack.DefinePlugin({
            "process.env.NODE_ENV": JSON.stringify("production"),
            "AppConfig": JSON.stringify({
                production: true,
                basePath: publicPath,
                buildVersion: env && env.buildVersion ? env.buildVersion : 'Unknown',
                buildDate: new Date()
            })
        })
    );
    return webpackProdConfig;
};
