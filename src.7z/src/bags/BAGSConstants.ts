const sourceSystemCode = "BAGS";

export { sourceSystemCode };