import * as React from "react";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import EntityBAGSContainer from "./EntityBAGS";
import "./EntityBAGSApplet.scss";

class EntityBAGSApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityBAGSContainer entityHandle={entityHandle} />
    }
    render() {
        return <EntityAppWrapper className="entity-source-applet entity-bags-applet"
                                 entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="BAGS"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntityBAGSApplet as default, EntityBAGSApplet }