import { AbstractRestService } from "./AbstractRestService";
import RestDataServiceConfig from "config/RestDataServiceConfig";

const NoResultErrorCode: string = "0101";

abstract class AbstractRestDataService extends AbstractRestService {
    get config() {
        return this._config || RestDataServiceConfig;
    }
    protected handleError(errors : any) : any {
        if(errors.code !== NoResultErrorCode) {
            throw errors;
        }
        return [];
    }
}

export { AbstractRestDataService as default, AbstractRestDataService, NoResultErrorCode };