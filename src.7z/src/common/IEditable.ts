interface IEditable {
    editing: boolean;
    setEditing(editing : boolean) : void;
}

export { IEditable as default, IEditable }