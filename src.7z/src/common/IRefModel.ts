import IHandleModel from "./IHandleModel";

export { IHandleModel as default, IHandleModel as IRefModel }