interface ISortProps {
    field: string;
    descending: boolean;
}

export { ISortProps as default, ISortProps }