import SyncType from "./SyncType";

interface ISync {
    id: string;
    type: SyncType;
    startDate: Date;
    endDate: Date;
    error: any;
    syncing: boolean;
    hasSynced: boolean;
}

export { ISync as default, ISync }
