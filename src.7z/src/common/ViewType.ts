enum ViewType {
    Detail,
    List,
    Tiles
}

export { ViewType as default, ViewType };