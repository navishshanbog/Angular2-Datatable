import { mergeStyles, mergeStyleSets } from "@uifabric/merge-styles";
import { DefaultPalette, DefaultFontStyles, FontSizes, IStyle, IStyleSet } from "@uifabric/styling";

interface IDetailsClassNames {
    root: string;
    header: string;
    summary: string;
    control: string;
    actionContainer: string;
    action: string;
    body: string;
}

const root : IStyle = {
    selectors: {
        "&.has-border": {
            borderWidth: "1px",
            borderColor: DefaultPalette.neutralSecondary,
            borderStyle: "solid"
        }
    }
};

const headerHeight = "28px";

const header : IStyle = Object.assign({},
    DefaultFontStyles.small,
    {
        display: "flex",
        justifyContent: "flex-start",
        alignItems: "center",
        position: "relative",
        backgroundColor: DefaultPalette.neutralSecondary,
        color: DefaultPalette.white,
        height: headerHeight,
        lineHeight: headerHeight,
        userSelect: "none",
        selectors: {
            "&:hover": {
                backgroundColor: DefaultPalette.orange
            },
            "&.is-control": {
                cursor: "pointer"
            }
        }
    }
);

const summary : IStyle = Object.assign({},
    DefaultFontStyles.small,
    {
        display: "flex",
        justifyContent: "flex-start",
        alignItems: "center",
        selectors: {
            ".ms-Icon": [
                {
                    fontSize: FontSizes.small,
                    paddingRight: "6px",
                    height: "16px",
                    lineHeight: "16px"
                }
            ]
        }
    }
);

const control : IStyle = Object.assign({},
    DefaultFontStyles.small,
    {
        outline: "none",
        color: DefaultPalette.white,
        selectors: {
            ".ms-Icon": [
                {
                    fontSize: FontSizes.small,
                    color: DefaultPalette.white
                }
            ]
        }
    }
);

const actionContainer : IStyle = {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    position: "absolute",
    top: "0px",
    right: "0px",
    bottom: "0px",
    background: "transparent",
    color: DefaultPalette.white
};

const action : IStyle = {
    color: DefaultPalette.white,
    selectors: {
        ".ms-Icon": [
            {
                fontSize: FontSizes.small,
                color: DefaultPalette.white
            }
        ]
    }
};

const body : IStyle = {
    position: "relative",
    overflow: "auto"
};

let classNames : IDetailsClassNames;

const getClassNames = () => {
    if(!classNames) {
        classNames = mergeStyleSets({
            root: root,
            header: header,
            summary: summary,
            control: control,
            actionContainer: actionContainer,
            action: action,
            body: body
        })
    }
    return classNames;
};

export { getClassNames, root, header, summary, control, actionContainer, action, body }