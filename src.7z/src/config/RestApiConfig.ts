import IUrlConfig from "./IUrlConfig";

const RestApiConfig : IUrlConfig = {
    baseUrl: "/analystdesktop/api"
};

export { RestApiConfig as default, RestApiConfig }