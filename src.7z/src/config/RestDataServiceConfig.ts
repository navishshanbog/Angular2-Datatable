import IUrlConfig from "./IUrlConfig";

const RestDataServicesConfig : IUrlConfig = {
    baseUrl: "/DataServices"
};

export { RestDataServicesConfig as default, RestDataServicesConfig };