import IUrlConfig from "./IUrlConfig";

const RestDataServicePNRConfig : IUrlConfig = {
    baseUrl: "/DataServicesPNR"
};

export { RestDataServicePNRConfig as default, RestDataServicePNRConfig };