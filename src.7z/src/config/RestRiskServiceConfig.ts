import IUrlConfig from "./IUrlConfig";

const RestRiskServiceConfig : IUrlConfig = {
    baseUrl: "/IntelTraveller"
};

export { RestRiskServiceConfig as default, RestRiskServiceConfig };