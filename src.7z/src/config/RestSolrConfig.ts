import IUrlConfig from "./IUrlConfig";

const RestSolrConfig : IUrlConfig = {
    baseUrl: "/DataServices/demo/solrPOST/"
};

export { RestSolrConfig as default, RestSolrConfig };