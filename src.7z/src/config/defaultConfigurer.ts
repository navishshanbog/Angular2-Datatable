const defaultConfigurer = () => {
    // does nothing
};

export { defaultConfigurer as default, defaultConfigurer };