import DashboardAddModel from "./DashboardAddModel";

const DashboardAddStore = new DashboardAddModel();

export { DashboardAddStore as default, DashboardAddStore }