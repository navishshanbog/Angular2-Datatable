import DashboardRemoveModel from "./DashboardRemoveModel";

const DashboardRemoveStore = new DashboardRemoveModel();

export { DashboardRemoveStore as default, DashboardRemoveStore }