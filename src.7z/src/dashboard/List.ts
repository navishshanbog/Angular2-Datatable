import Stack from "./Stack";
import { list } from "./ComponentTypes";

class List extends Stack {
    get type() {
        return list;
    }
}

export { List as default, List }