import { observable, action, computed, autorun } from "mobx";
import SyncModel from "common/SyncModel";
import IComponent from "./IComponent";
import { IWindow, IWindowHeader } from "./IWindow";
import IWindowManager from "./IWindowManager";
import AppComponent from "./AppComponent";
import { isString, isNumber, isBoolean, isDate } from "util/Lang";
import IRequest from "roota/lib/IRequest";
import Component from "./Component";
import { dispatchWindowResize } from "./DOMHelper";
import * as qs from "qs";

const ComponentType = "window";

class Window extends AppComponent implements IWindow {
    private _el : HTMLElement;
    unmountHandler : () => void;
    @observable private _contentHidden : boolean = false;
    @observable private _closeDisabled = false;

    constructor() {
        super();
        this.addEventListener("resize", this._onResize);
    }

    private _onResize = () => {
        dispatchWindowResize();
    }

    get el() {
        if(!this._el) {
            this._el = document.createElement("div");
        }
        return this._el;
    }

    get root() {
        return false;
    }

    @computed
    get closeDisabled() {
        return this._closeDisabled || (this.manager && this.manager.closeDisabled);
    }
    set closeDisabled(value) {
        this._closeDisabled = value;
    }

    @computed
    get contentHidden() {
        return this._contentHidden;
    }
    set contentHidden(value) {
        this.setContentHidden(value);
    }
    @action
    setContentHidden(contentHidden : boolean) {
        if(contentHidden !== this.contentHidden) {
            this._contentHidden = contentHidden;
            // TODO: updateing bounds
        }
    }
    @action
    toggleContent() {
        this._contentHidden = !this._contentHidden;
    }

    @action
    setCloseDisabled(closeDisabled : boolean) : void {
        this._closeDisabled = closeDisabled;
    }

    @computed
    get manager() : IWindowManager {
        return this.parent as IWindowManager;
    }

    get type() {
        return ComponentType;
    }

    @computed
    get active() {
        const manager = this.manager;
        return manager ? manager.active === this : false;
    }

    @action
    activate() {
        const manager = this.manager;
        if(manager) {
            manager.setActive(this);
        }
    }

    @computed
    get config() {
        return {
            type: this.type,
            title: this.saveLocation ? this._title : undefined, // NOTE that we don't track even initial title when not saving location
            path: this.saveLocation ? this._path : this._initPath,
            params: this.saveLocation ? this._params : this._initParams,
            closeDisabled: this._closeDisabled,
            contentHidden: this._contentHidden
        };
    }

    @action
    setConfig(config) {
        this.setTitle(config ? config.title : undefined);
        this.setCloseDisabled(config ? config.closeDisabled : undefined);
        this.setPath(config ? config.path : undefined);
        this.setParams(config ? config.params : undefined);
        this.setContentHidden(config ? config.contentHidden : undefined);
        return Promise.resolve();
    }

    open(request : IRequest) {
        const manager = this.manager;
        if(manager) {
            return manager.open(request);
        }
        return undefined;
    }

    @action
    unmount() {
        if(this.unmountHandler) {
            this.unmountHandler();
        }
    }
}

export { Window as default, Window }