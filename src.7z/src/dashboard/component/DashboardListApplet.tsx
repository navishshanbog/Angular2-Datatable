import * as React from "react";
import IAppHost from "app/IAppHost";
import AppHostWrapper from "app/component/AppHostWrapper";
import AppContainer from "app/component/AppContainer";
import { DashboardListContainer } from "./DashboardList";
import DashboardListStore from "../DashboardListStore";
import DashboardListMenuButton from "./DashboardListMenuButton";

interface IDashboardListAppletProps {
    host: IAppHost;
}

class DashboardListApplet extends React.Component<IDashboardListAppletProps, any> {
    componentWillMount() {
        DashboardListStore.load();
    }
    componentDidMount() {
        this.props.host.setTitle("Dashboards");
    }
    render() {
        const title = <DashboardListMenuButton dashboardList={DashboardListStore} />;
        const farItems = [
            { path: "/dashboard/layout" }
        ];
        return (
            <AppHostWrapper className="dashboard-list-applet" host={this.props.host} title={title} farItems={farItems}>
                <DashboardListContainer dashboardList={DashboardListStore} host={this.props.host} />
            </AppHostWrapper>
        );
    }
}

export { DashboardListApplet as default, DashboardListApplet }