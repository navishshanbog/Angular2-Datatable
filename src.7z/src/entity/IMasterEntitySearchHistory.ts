import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";


interface IMasterEntitySearchHistory {
    entries: IMasterEntitySearchRequestEntry[];
}

export { IMasterEntitySearchHistory as default, IMasterEntitySearchHistory };