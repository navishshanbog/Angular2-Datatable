import * as React from "react";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityAppWrapper from "./EntityAppWrapper";
import MasterEntityContainer from "./MasterEntityContainer";
import MasterEntitySourceDashboard from "./MasterEntitySourceDashboard";
import IMasterEntityModel from "../IMasterEntityModel";
import IMasterEntitySearchRequest from "../IMasterEntitySearchRequest";
import "./EntitySourcesApplet.scss";

interface IEntitySourcesAppletProps extends IEntityAppletProps {
    onSearch?: (request : IMasterEntitySearchRequest) => void;
}

interface IEntitySourcesCommandBarProps {
    masterEntity: IMasterEntityModel;
}

class EntitySourcesApplet extends React.Component<IEntitySourcesAppletProps, any> {
    private _onRenderEntity = (entity) => {
        return <MasterEntitySourceDashboard masterEntity={entity} host={this.props.host} onSearch={this.props.onSearch} />
    }
    private _onRenderContent = (entityHandle) => {
        return <MasterEntityContainer entityHandle={entityHandle} onRenderEntity={this._onRenderEntity} />
    }
    render() {
        return <EntityAppWrapper entityId={this.props.entityId}
                                 className="entity-sources-applet"
                                 host={this.props.host}
                                 title="Entity Sources"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntitySourcesApplet as default, EntitySourcesApplet }