import * as React from "react";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityAppWrapper from "./EntityAppWrapper";
import MasterEntityContainer from "./MasterEntityContainer";
import MasterEntitySummary from "./MasterEntitySummary";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";

class EntitySummaryApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderEntity = (entity) => {
        return <MasterEntitySummary masterEntity={entity} onSearch={this.props.host.params.onSearch} />;
    }
    private _onRenderContent = (entityHandle) => {
        return <MasterEntityContainer entityHandle={entityHandle} onRenderEntity={this._onRenderEntity} />
    }
    render() {
        return <EntityAppWrapper entityId={this.props.entityId}
                                 className="entity-summary-applet"
                                 host={this.props.host}
                                 title="Entity Summary"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntitySummaryApplet as default, EntitySummaryApplet }