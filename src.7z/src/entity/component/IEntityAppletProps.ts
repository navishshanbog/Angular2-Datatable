import IAppletProps from "app/component/IAppletProps";
import IMasterEntitySearchRequest from "../IMasterEntitySearchRequest";

interface IEntityAppletProps extends IAppletProps {
    entityId: string;
    onSearch?: (request : IMasterEntitySearchRequest) => void;
}

export { IEntityAppletProps as default, IEntityAppletProps }