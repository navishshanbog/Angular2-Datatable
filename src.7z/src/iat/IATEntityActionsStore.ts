import SelectionModel from "common/SelectionModel";

const IATEntityActionsStore = new SelectionModel();

export { IATEntityActionsStore as default, IATEntityActionsStore };