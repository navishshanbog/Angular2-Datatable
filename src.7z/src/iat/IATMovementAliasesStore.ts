import IATMovementAliasesModel from "./IATMovementAliasesModel";

const IATMovementAliasesStore = new IATMovementAliasesModel();

export { IATMovementAliasesStore as default, IATMovementAliasesStore };