import IATMovementDetailModel from "./IATMovementDetailModel";

const IATMovementDetailStore = new IATMovementDetailModel();

export { IATMovementDetailStore as default, IATMovementDetailStore };