import IATMovementPassportsModel from "./IATMovementPassportsModel";

const IATMovementPassportsStore = new IATMovementPassportsModel();

export { IATMovementPassportsStore as default, IATMovementPassportsStore };