import IATMovementVisasModel from "./IATMovementVisasModel";

const IATMovementVisasStore = new IATMovementVisasModel();

export { IATMovementVisasStore as default, IATMovementVisasStore };