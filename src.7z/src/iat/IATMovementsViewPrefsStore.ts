import ViewPreferencesModel from "common/ViewPreferencesModel";

const IATMovementsViewPrefsStore = new ViewPreferencesModel("iatMovements");

export { IATMovementsViewPrefsStore as default, IATMovementsViewPrefsStore }