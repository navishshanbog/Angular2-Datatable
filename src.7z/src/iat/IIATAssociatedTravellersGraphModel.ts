interface IIATAssociatedTravellersGraphModel {
    nodes: any[];
    edges: any[];
}

export { IIATAssociatedTravellersGraphModel as default, IIATAssociatedTravellersGraphModel };