import * as React from "react";
import { observer } from "mobx-react";
import { IObjectWithKey } from "office-ui-fabric-react/lib/Selection";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import IATMovementList from "./IATMovementList";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import { MasterEntityContainer, IMasterEntityContainerProps } from "entity/component/MasterEntityContainer";
import MasterEntitySourceContainer from "entity/component/MasterEntitySourceContainer";
import IIATMovement from "../IIATMovement";
import IIATAlias from "../IIATAlias";
import IATEntityActionsStore from "../IATEntityActionsStore";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import Error from "common/component/Error";
import * as IATConstants from "../IATConstants";
import IATAssociatedActivityColumnsList from "./IATAssociatedActivityColumnsList";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IMasterEntitySourceModel from "entity/IMasterEntitySourceModel";
import { getSourceMovementList, getSourceAliasList } from "../IATMovementHelper";
import IMasterEntitySourceListModel from "entity/IMasterEntitySourceListModel";
import SyncContainer from "common/component/SyncContainer";
import IATMovementPassports from "./IATMovementPassports";
import IATMovementVisas from "./IATMovementVisas";
import IATMovementAliases from "./IATMovementAliases";
import IATMovementDetail from "./IATMovementDetail";
import IATFlightList from "./IATFlightList";
import IATMovementPassportsStore from "../IATMovementPassportsStore";
import IATMovementVisasStore from "../IATMovementVisasStore";
import IATMovementDetailStore from "../IATMovementDetailStore";
import IATMovementAliasesStore from "../IATMovementAliasesStore";
import IATFlightListStore from "../IATFlightListStore";
import IMasterEntitySearchRequest from "entity/IMasterEntitySearchRequest";
import { openAliases } from "../IATActions";

interface IATAliasInfoProps {
    aliasList: IMasterEntitySourceListModel<IIATAlias>;
}

class EntityIATAliasInfo extends React.Component<IATAliasInfoProps, any> {
    private _onClickViewAliases = (e : React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        // NOTE: have to make use of the alias list instance instead of the store
        openAliases(this.props.aliasList.source);
    }
    private _onRenderDone = () => {
        if(this.props.aliasList.total > 0) {
            return <MessageBar messageBarType={MessageBarType.warning}>Traveller exists in IAT system, but has no movements. You can <a href="#" onClick={this._onClickViewAliases}>View Aliases</a></MessageBar>;
        }
        return <MessageBar messageBarType={MessageBarType.error}>There are no IAT details available for the selected Master Entity</MessageBar>;
    }
    render() {
        return <SyncContainer sync={this.props.aliasList.sync} onRenderDone={this._onRenderDone} />
    }
}

interface IEntityIATSourceContentProps {
    movementList: IMasterEntitySourceListModel<IIATMovement>;
}

class EntityIATSourceContent extends React.Component<IEntityIATSourceContentProps, any> {
    private _onRenderDone = () => {
        if(this.props.movementList.total > 0) {
            return <IATMovementList list={this.props.movementList} />
        }
        return <EntityIATAliasInfo aliasList={getSourceAliasList(this.props.movementList.source)} />;
    }
    render() {
        return <SyncContainer sync={this.props.movementList.sync} syncLabel="Loading IAT Summary..." onRenderDone={this._onRenderDone} />;
    }
}

interface IEntityIATSourceProps {
    source: IMasterEntitySourceModel;
    onSearch?: (request : IMasterEntitySearchRequest) => void;
}

@observer
class EntityIATSource extends React.Component<IEntityIATSourceProps, any> {
    render() {
        let passports = IATMovementPassportsStore.visible ? <IATMovementPassports model={IATMovementPassportsStore}/> : undefined;
        let visas = IATMovementVisasStore.visible ? <IATMovementVisas model={IATMovementVisasStore}/> : undefined;
        let aliases = IATMovementAliasesStore.visible ? <IATMovementAliases model={IATMovementAliasesStore}/> : undefined;
        let movementDetail = IATMovementDetailStore.visible ? <IATMovementDetail model={IATMovementDetailStore}/> : undefined;
        let flightList = IATFlightListStore.visible ? <IATFlightList model={IATFlightListStore}
                                                                     masterEntity={this.props.source.masterEntity}
                                                                     onSearch={this.props.onSearch} /> : undefined;
        return (
            <div className="entity-source entity-iat">
                <div className="entity-source-header entity-iat-header">
                    <EntityAttributes entity={this.props.source} type={EntityAttributesType.secondary} />
                </div>
                <div className="entity-source-body entity-iat-body">
                    <EntityIATSourceContent movementList={getSourceMovementList(this.props.source)} />
                    {passports}
                    {visas}
                    {aliases}
                    {movementDetail}
                    {flightList}
                </div>
            </div>
        );
    }
}

interface IEntityIATSourceContainerProps {
    entity: IMasterEntityModel;
    onSearch?: (request : IMasterEntitySearchRequest) => void;
}

class EntityIATSourceContainer extends React.Component<IEntityIATSourceContainerProps, any> {
    private _onRenderSource = (source) => {
        return <EntityIATSource source={source} onSearch={this.props.onSearch} />
    }
    render() {
        return <MasterEntitySourceContainer
                    masterEntity={this.props.entity}
                    sourceSystemCode={IATConstants.sourceSystemCode}
                    onRenderSource={this._onRenderSource}
                    className="entity-iat-source-container" />;
    }
}

interface IEntityIATContainerProps extends IMasterEntityContainerProps {
    onSearch?: (request : IMasterEntitySearchRequest) => void;
}

class EntityIATContainer extends React.Component<IEntityIATContainerProps, any> {
    private _onRenderEntity = (entity) => {
        return <EntityIATSourceContainer entity={entity} onSearch={this.props.onSearch} />
    }
    private _onRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the IAT summary</MessageBar>;
    }
    render() {
        return <MasterEntityContainer entityHandle={this.props.entityHandle}
                                        onRenderEntity={this._onRenderEntity}
                                        onRenderNotLoaded={this._onRenderNotLoaded} />;
    }
}

export {
    EntityIATContainer as default,
    EntityIATContainer
}