import * as React from "react";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import EntityIATContainer from "./EntityIAT";
import "./EntityIATApplet.scss";

class EntityIATApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityIATContainer entityHandle={entityHandle} onSearch={this.props.onSearch} />;
    }
    render() {
        return <EntityAppWrapper className="entity-source-applet entity-iat-applet"
                                 entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="IAT"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntityIATApplet as default, EntityIATApplet }