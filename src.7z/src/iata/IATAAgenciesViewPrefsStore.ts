import ViewPreferencesModel from "common/ViewPreferencesModel";

const IATAAgenciesViewPrefsStore = new ViewPreferencesModel("iataAgencies");

export { IATAAgenciesViewPrefsStore as default, IATAAgenciesViewPrefsStore }