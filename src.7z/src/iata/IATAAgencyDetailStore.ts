import IATAAgencyDetailModel from "./IATAAgencyDetailModel";

const IATAAgencyDetailStore = new IATAAgencyDetailModel();

export { IATAAgencyDetailStore as default, IATAAgencyDetailStore };