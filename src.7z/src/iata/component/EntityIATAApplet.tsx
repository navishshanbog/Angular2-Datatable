import * as React from "react";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityIATAContainer from "./EntityIATA";
import "./EntityIATAApplet.scss";

class EntityIATAApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityIATAContainer entityHandle={entityHandle} />
    }
    render() {
        return <EntityAppWrapper className="entity-source-applet entity-iata-applet"
                                 entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="IATA"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntityIATAApplet as default, EntityIATAApplet }