const sourceSystemCode = "INTCP";

export { sourceSystemCode }