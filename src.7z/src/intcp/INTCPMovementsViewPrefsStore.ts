import ViewPreferencesModel from "common/ViewPreferencesModel";

const INTCPMovementsViewPrefsStore = new ViewPreferencesModel("intcpMovements");

export { INTCPMovementsViewPrefsStore as default, INTCPMovementsViewPrefsStore }