import * as React from "react";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityINTCPContainer from "./EntityINTCP";
import "./EntityINTCPApplet.scss";

class EntityINTCPApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityINTCPContainer entityHandle={entityHandle} />
    }
    render() {
        return <EntityAppWrapper className="entity-source-applet entity-intcp-applet"
                                 entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="INTCP"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntityINTCPApplet as default, EntityINTCPApplet }