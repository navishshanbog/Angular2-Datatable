import { action } from "mobx";
import ISyncHandle from "common/ISyncHandle";
import SyncHandleModel from "common/SyncHandleModel";
import IAppletListingModel from "./IAppletListingModel";
import UserAppletListingServiceContext from "./UserAppletListingServiceContext";
import { IAppletListing } from "listing/IAppletListing";
import { AppletListingModel } from "listing/AppletListingModel";

const _listingLoaded = action((handle : SyncHandleModel<IAppletListingModel>, data : IAppletListing) => {
    handle.setValue(new AppletListingModel(data));
    handle.sync.syncEnd();
});

const _listingLoadError = action((handle : SyncHandleModel<IAppletListingModel>, error : any) => {
    handle.clearValue();
    handle.sync.syncError(error);
});

const findById = (id : string) => {
    const handle = new SyncHandleModel<IAppletListingModel>();
    handle.sync.syncStart({ id: id });
    UserAppletListingServiceContext.value.getUserAppletListingById({ listingId: id }).then(data => {
        _listingLoaded(handle, data);
    }).catch(error => {
        _listingLoadError(handle, error);
    });
    return handle;
};

export { findById }