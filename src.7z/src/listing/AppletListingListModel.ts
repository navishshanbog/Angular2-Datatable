import { action } from "mobx";
import IAppletListing from "listing/IAppletListing";
import IAppletListingListModel from "./IAppletListingListModel";
import ListModel from "common/ListModel";
import UserAppletListingServiceContext from "listing/UserAppletListingServiceContext";

class AppletListingListModel extends ListModel<IAppletListing> implements IAppletListingListModel {

    @action
    refresh() {
        const syncId = String(new Date().getTime());
        this.sync.syncStart({ id: syncId });
        return UserAppletListingServiceContext.value.getUserAppletListings().then((items) => {
            if(syncId === this.sync.id) {
                this.setItems(items);
            }
        }).catch((error) => {
            if(syncId === this.sync.id) {
                this.clearItems();
                this.sync.syncError(error);
            }
        });
    }

    @action
    load() : Promise<any> {
        if(!this.sync.syncing && (!this.sync.hasSynced || this.sync.error)) {
            return this.refresh();
        }
        return Promise.resolve();
    }
}

export { AppletListingListModel as default, AppletListingListModel }