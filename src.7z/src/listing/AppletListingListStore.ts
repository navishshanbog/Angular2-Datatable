import AppletListingListModel from "./AppletListingListModel";

const AppletListingListStore = new AppletListingListModel();

export { AppletListingListStore as default, AppletListingListStore }