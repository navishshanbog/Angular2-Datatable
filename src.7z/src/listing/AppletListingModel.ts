import IAppletListing from "./IAppletListing";
import IAppletListingModel from "./IAppletListingModel";
import IUserProfile from "user/IUserProfile";
import { observable, action, computed } from "mobx";
import IUserAppletListingService from "./IUserAppletListingService";
import UserAppletListingServiceContext from "./UserAppletListingServiceContext";
import SyncModel from "common/SyncModel";

class AppletListingModel implements IAppletListingModel {
    @observable saveSync = new SyncModel();
    @observable private _id: string;
    @observable private _title: string;
    @observable private _description: string;
    @observable private _shortDescription : string;
    @observable private _enabled: boolean = true;
    @observable private _path: string;
    @observable private _authGroup: string;
    @observable private _owners : IUserProfile[] = [];
    @observable private _version : string;

    private _listingService : IUserAppletListingService;

    constructor(data?: IAppletListing) {
        if(data) {
            this.setData(data);
        }
    }

    get listingService() {
        return this._listingService || UserAppletListingServiceContext.value;
    }
    set listingService(value : IUserAppletListingService) {
        this._listingService = value;
    }

    get data() {
        return {
            id: this._id,
            title: this._title,
            description: this._description,
            shortDescription: this._shortDescription,
            enabled: this._enabled,
            path: this._path,
            authGroup: this._authGroup,
            owners: this._owners ? this._owners.slice(0) : [],
            version: this._version
        };
    }
    set data(value) {
        this.setData(value);
    }

    @action
    setData(data : IAppletListing) {
        this._id = data ? data.id : undefined;
        this._title = data ? data.title : undefined;
        this._description = data ? data.description : undefined;
        this._shortDescription = data ? data.shortDescription : undefined;
        this._enabled = data ? data.enabled : true;
        this._path = data ? data.path : undefined;
        this._authGroup = data ? data.authGroup : undefined;
        this._owners = data && data.owners ? data.owners : [];
        this._version = data ? data.version : undefined;
    }

    @computed
    get id() {
        return this._id;
    }

    @computed
    get title() {
        return this._title;
    }
    set title(value) {
        this.setTitle(value);
    }

    @action
    setTitle(title : string) : void {
        this._title = title;
    }

    @computed
    get description() {
        return this._description;
    }
    set description(value) {
        this.setDescription(value);
    }

    @action
    setDescription(description : string) : void {
        this._description = description;
    }

    @computed
    get shortDescription() {
        return this._shortDescription;
    }
    set shortDescription(value) {
        this.setShortDescription(value);
    }

    @action
    setShortDescription(shortDescription : string) : void {
        this._shortDescription = shortDescription;
    }

    @computed
    get enabled() {
        return this._enabled;
    }
    set enabled(value) {
        this._enabled = value;
    }

    @action
    setEnabled(enabled : boolean) : void {
        this._enabled = enabled;
    }

    @computed
    get path() {
        return this._path;
    }
    set path(value) {
        this.setPath(value);
    }

    @action
    setPath(path : string) : void {
        this._path = path;
    }

    @computed
    get authGroup() {
        return this._authGroup;
    }
    set authGroup(value) {
        this.setAuthGroup(value);
    }

    @action
    setAuthGroup(authGroup : string) : void {
        this._authGroup = authGroup;
    }

    @computed
    get version() {
        return this._version;
    }
    set version(value) {
        this._version = value;
    }

    @action
    setVersion(version : string) {
        this._version = version;
    }

    @action
    private _onSaveDone = (data : IAppletListing) => {
        this.saveSync.syncEnd();
    }

    @action
    private _onSyncError = (error) => {
        this.saveSync.syncError(error);
    }

    @action
    save() {
        // TODO: validate
        
        this.saveSync.syncStart();
        return this.listingService.saveListing(this.data).then(this._onSaveDone).catch(this._onSyncError);
    }
}

export { AppletListingModel as default, AppletListingModel }