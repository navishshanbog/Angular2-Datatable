import * as React from "react";
import Router from "roota/lib/Router";
import UserGroup from "user/UserGroup";
import { createAuthHandler } from "app/AuthHandler";
import { exactPath } from "common/RouterUtils";

const r = new Router();
r.use(exactPath(req => {
    return import("listing/component/AppletListing").then(m => {
        return <m.AppletListingListApplet host={req.app} />;
    });
}, true));
r.use(createAuthHandler(UserGroup.ADMIN));
r.use("/:listingId", exactPath(req => {
    return import("listing/component/AppletListing").then(m => {
        return <m.AppletListingApplet host={req.app} listingId={req.params.listingId} />;
    });
}));

export { r as default, r as AdminRouter }