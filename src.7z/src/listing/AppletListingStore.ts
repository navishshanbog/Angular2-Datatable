import AppletListingModel from "./AppletListingModel";

const AppletListingStore = new AppletListingModel();

export { AppletListingStore as default, AppletListingStore }