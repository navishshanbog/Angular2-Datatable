import IUserProfile from "user/IUserProfile";

interface IAppletListing {
    id: string;
    title: string;
    description?: string;
    shortDescription?: string;
    enabled?: boolean;
    path: string;
    authGroup?: string;
    owners?: IUserProfile[];
    version?: string;
}

export { IAppletListing as default, IAppletListing }