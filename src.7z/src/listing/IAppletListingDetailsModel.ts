import IAppletListing from "./IAppletListing";

interface IAppletListingDetailsModel extends IAppletListing {

}

export { IAppletListingDetailsModel as default, IAppletListingDetailsModel }