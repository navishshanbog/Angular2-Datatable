import IAppletListing from "listing/IAppletListing";
import IListModel from "common/IListModel";

interface IAppletListingListModel extends IListModel<IAppletListing> {
    refresh() : Promise<any>;
    load() : Promise<any>;
}

export { IAppletListingListModel as default, IAppletListingListModel };