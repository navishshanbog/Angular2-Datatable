import IAppletListing from "./IAppletListing";
import ISync from "common/ISync";

interface IAppletListingModel extends IAppletListing {
    saveSync : ISync;
    setTitle(title : string) : void;
    setDescription(description : string) : void;
    setShortDescription(shortDescription : string) : void;
    setEnabled(enabled : boolean) : void;
    setPath(path : string) : void;
    setAuthGroup(authGroup : string) : void;
    setVersion(version : string) : void;
    save() : Promise<any>;
}

export { IAppletListingModel as default, IAppletListingModel }