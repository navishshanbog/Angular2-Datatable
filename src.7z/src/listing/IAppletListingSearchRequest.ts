interface IAppletListingSearchRequest {
    search?: string;
    category?: string[];
    limit?: number;
    offset?: number;
}

export { IAppletListingSearchRequest as default, IAppletListingSearchRequest }