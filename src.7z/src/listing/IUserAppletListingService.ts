import IAppletListing from "./IAppletListing";

interface IGetListingByIdRequest {
    listingId: string;
}

interface IUserAppletListingService {
    getUserAppletListingById(request : IGetListingByIdRequest) : Promise<IAppletListing>;
    saveListing(request : IAppletListing) : Promise<IAppletListing>;
    getUserAppletListings() : Promise<IAppletListing[]>;
}

export { IUserAppletListingService as default, IUserAppletListingService, IGetListingByIdRequest }