import IAppletListing from "./IAppletListing";
import { IUserAppletListingService, IGetListingByIdRequest } from "./IUserAppletListingService";

class MockUserAppletListingService implements IUserAppletListingService {
    throwError : boolean = false;
    listings: IAppletListing[] = [
        {
            id: "1",
            enabled: true,
            title: "Entity Search",
            path: "/entity/search",
            authGroup: "analyst_desktop_entity_search"
        },
        {
            id: "2",
            enabled: true,
            title: "Clipboard",
            path: "/entity/profile",
            authGroup: "analyst_desktop_entity_search"
        },
        {
            id: "3",
            enabled: true,
            title: "ME Case Management",
            path: "/me/portal",
            authGroup: "analyst_desktop_match_evaluation"
        },
        {
            id: "4",
            enabled: true,
            title: "Risk Resume Search",
            path: "/vra/search",
            authGroup: "analyst_desktop_risk_resume"
        },
        {
            id: "5",
            enabled: true,
            title: "PNR Search",
            path: "/pnr/search",
            authGroup: "analyst_desktop_pnr_search"
        },
        {
            id: "6",
            enabled: true,
            title: "Risk PNR Get Current Booking Test",
            path: "/risk/traveller/pnr/GetCurrentBookingData",
            authGroup: "analyst_desktop_pnr_search"
        }
    ];
    saveListing(request : IAppletListing) : Promise<any> {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if(this.throwError) {
                    reject({ message: "Mock Service Error" });
                } else {
                    let r;
                    if(request.id) {
                        // find the listing
                        const idx = this.listings.findIndex(l => l.id === request.id);
                        if(idx < 0) {
                            return Promise.reject({ code: "NOT_FOUND", message: `Unable to find listing for id ${request ? request.id : undefined}`})
                        }
                        r = Object.assign({}, request);
                        this.listings[idx] = Object.assign({}, request);
                    } else {
                        const lastEntry = this.listings[this.listings.length - 1];
                        const lastId = parseInt(lastEntry.id);
                        const newId = lastId + 1;
                        r = Object.assign({}, request, { id: newId });
                    }
                    resolve(r);
                }
            }, 5000);
        });
    }
    getUserAppletListingById(request : IGetListingByIdRequest) : Promise<IAppletListing> {
        let r;
        if(request && request.listingId) {
            r = this.listings.find(l => l.id === request.listingId);
        }
        if(!r) {
            return Promise.reject({ code: "NOT_FOUND", message: `Unable to find listing for id ${request ? request.listingId : undefined}`})
        }
        return Promise.resolve(r);
    }
    getUserAppletListings() : Promise<IAppletListing[]> {
        return Promise.resolve(this.listings);
    }
}

export { MockUserAppletListingService as default, MockUserAppletListingService }
