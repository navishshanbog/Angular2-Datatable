import axios from "axios";
import IAppletListing from "./IAppletListing";
import { IUserAppletListingService, IGetListingByIdRequest } from "./IUserAppletListingService";
import AbstractRestService from "common/AbstractRestService";
import RestApiConfig from "config/RestApiConfig";
import { IOzoneUserProfile, mapFromOzoneUserProfile, mapToOzoneUserProfile } from "user/RestUserProfileService";
import * as StringUtils from "util/String";

interface IOzoneWidgetListingType {
    title: string;
}

interface IOzoneWidgetListing {
    id: number;
    unique_name: string;
    title: string;
    is_enabled: boolean;
    is_featured: boolean;
    description: string;
    description_short: string;
    launch_url: string;
    security_marking?: string;
    owners: IOzoneUserProfile[];
    version_name: string;
    requirements: string;
    what_is_new: string;
}

const mapFromOzoneListing = (value : IOzoneWidgetListing) : IAppletListing => {
    if(value) {
        return {
            id: String(value.id),
            title: value.title,
            description: value.description,
            shortDescription: value.description_short,
            enabled: value.is_enabled,
            path: value.launch_url,
            authGroup: value.security_marking,
            owners: value.owners ? value.owners.map(mapFromOzoneUserProfile) : [],
            version: value.version_name
        };
    }
};

const mapFromOzoneListings = (value : IOzoneWidgetListing[]) : IAppletListing[] => {
    return value ? value.map(mapFromOzoneListing) : [];
};

const createUniqueName = (value : IAppletListing) : string => {
    return `dibp.analystdesktop.${StringUtils.wordsToCamelCase(value.title)}`;
};

const mapToOzoneListing = (value : IAppletListing) : IOzoneWidgetListing => {
    if(value) {
        return {
            id: parseInt(value.id),
            unique_name: createUniqueName(value),
            title: value.title,
            description: StringUtils.isNotBlank(value.description) ? value.description : value.title,
            description_short: StringUtils.isNotBlank(value.shortDescription) ? value.shortDescription : value.title, 
            is_enabled: value.enabled,
            is_featured: true,
            launch_url: value.path,
            security_marking: value.authGroup,
            requirements: "None",
            what_is_new: "None",
            owners: value.owners ? value.owners.map(mapToOzoneUserProfile) : [],
            version_name: value.version
        };
    }
};

class RestUserAppletListingService extends AbstractRestService implements IUserAppletListingService {
    get config() {
        return this._config || RestApiConfig;
    }
    getUserAppletListingById(request : IGetListingByIdRequest) : Promise<IAppletListing> {
        return axios.get(`${this.config.baseUrl}/listing/${encodeURIComponent(request ? request.listingId : undefined)}/`).then(ar => {
            return mapFromOzoneListing(ar.data as IOzoneWidgetListing);
        });
    }
    getUserAppletListings() : Promise<IAppletListing[]> {
        return axios.get(`${this.config.baseUrl}/listings/search/`).then((value) => {
            return mapFromOzoneListings(value.data as IOzoneWidgetListing[]);
        });
    }
    saveListing(request : IAppletListing) : Promise<IAppletListing> {
        const ozoneRequest = mapToOzoneListing(request);
        const p = request.id ?
                    axios.put(`${this.config.baseUrl}/listing/${encodeURIComponent(request.id)}/`, ozoneRequest) :
                    axios.post(`${this.config.baseUrl}/listing/`, ozoneRequest);
        return p.then(ar => {
            return mapFromOzoneListing(ar.data as IOzoneWidgetListing);
        });
    }
}

export { RestUserAppletListingService as default, RestUserAppletListingService }
