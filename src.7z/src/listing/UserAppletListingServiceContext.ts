import Context from "common/Context";
import IUserAppletListingService from "./IUserAppletListingService";
import RestUserAppletListingService from "./RestUserAppletListingService";

const UserAppletListingServiceContext = new Context<IUserAppletListingService>({
    factory() {
        return new RestUserAppletListingService();
    }
});

export { UserAppletListingServiceContext as default, UserAppletListingServiceContext };