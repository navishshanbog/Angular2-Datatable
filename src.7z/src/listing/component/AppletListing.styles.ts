import { mergeStyles, mergeStyleSets } from "@uifabric/merge-styles";
import { DefaultPalette, DefaultFontStyles, FontSizes, FontWeights, IStyle, IStyleSet } from "@uifabric/styling";
import AppletListingBackground from "./AppletListingBackground.png";

interface IAppletListingClassNames {
    root: string;
    actions: string;
    applet: string;
}

const root : IStyle = {
    padding: 10
};

const actions : IStyle = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    selectors: {
        ".action+.action": {
            marginLeft: 8
        }
    }
};

const applet : IStyle = {
    position: "absolute",
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    backgroundImage: `url(${AppletListingBackground})`,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "50% 60%"
};

let merged : IAppletListingClassNames;
const getMerged = () => {
    if(!merged) {
        merged = mergeStyleSets({
            root: root,
            actions: actions,
            applet: applet
        });
    }
    return merged;
};

const ClassNames : IAppletListingClassNames = {
    get root() {
        return getMerged().root;
    },
    get actions() {
        return getMerged().actions;
    },
    get applet() {
        return getMerged().applet;
    }
}

export { ClassNames, root }

