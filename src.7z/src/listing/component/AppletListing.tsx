import * as React from "react";
import { observer } from "mobx-react";
import IAppletProps from "app/component/IAppletProps";
import IAppHost from "app/IAppHost";
import AppHostWrapper from "app/component/AppHostWrapper";
import IAppletListing from "../IAppletListing";
import IAppletListingModel from "../IAppletListingModel";
import AppletListingListModel from "../AppletListingListModel";
import { findById } from "../AppletListingFinder";
import AppletSelector from "./AppletSelector";
import ISyncHandle from "common/ISyncHandle";
import SyncContainer from "common/component/SyncContainer";
import { IAppletListingListModel } from "listing/IAppletListingListModel";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { Checkbox } from "office-ui-fabric-react/lib/Checkbox";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import { css } from "office-ui-fabric-react/lib/Utilities";
import { ClassNames } from "./AppletListing.styles";
import { DefaultButton } from "office-ui-fabric-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { Spinner, SpinnerSize } from "office-ui-fabric-react/lib/Spinner";
import Error from "common/component/Error";

interface IAppletListingProps {
    listing: IAppletListingModel;
    onCancel?: () => void;
    onAfterSave?: () => void;
}

@observer
class AppletListingEditor extends React.Component<IAppletListingProps, any> {
    private _onTitleChanged = (value : string) => {
        this.props.listing.setTitle(value);
    }
    private _onDescriptionChanged = (value : string) => {
        this.props.listing.setDescription(value);
    }
    private _onShortDescriptionChanged = (value : string) => {
        this.props.listing.setShortDescription(value);
    }
    private _onEnabledChanged = (e : React.MouseEvent<HTMLElement>, value : boolean) => {
        this.props.listing.setEnabled(value);
    }
    private _onPathChanged = (value : string) => {
        this.props.listing.setPath(value);
    }
    private _onVersionChanged = (value : string) => {
        this.props.listing.setVersion(value);
    }
    private _onAuthGroupChanged = (value : string) => {
        this.props.listing.setAuthGroup(value);
    }
    render() {
        return (
            <div className={css("applet-listing-editor")}>
                <TextField onChanged={this._onTitleChanged} value={this.props.listing.title || ""} label="Title" disabled={this.props.listing.saveSync.syncing} />
                <TextField onChanged={this._onDescriptionChanged} value={this.props.listing.description || ""} label="Description" disabled={this.props.listing.saveSync.syncing} />
                <TextField onChanged={this._onShortDescriptionChanged} value={this.props.listing.shortDescription || ""} label="Short Description" disabled={this.props.listing.saveSync.syncing} />
                <TextField onChanged={this._onPathChanged} value={this.props.listing.path || ""} label="Path" disabled={this.props.listing.saveSync.syncing} />
                <TextField onChanged={this._onVersionChanged} value={this.props.listing.version || ""} label="Version" disabled={this.props.listing.saveSync.syncing} />
                <TextField onChanged={this._onAuthGroupChanged} value={this.props.listing.authGroup || ""} label="Auth Group" disabled={this.props.listing.saveSync.syncing} />
                <Checkbox onChange={this._onEnabledChanged} checked={this.props.listing.enabled ? true : false} label="Enabled" disabled={this.props.listing.saveSync.syncing} />
            </div>
        );
    }
}

@observer
class AppletListingSaveAction extends React.Component<IAppletListingProps, any> {
    private _onClick = () => {
        this.props.listing.save().then(() => {
            if(!this.props.listing.saveSync.error && this.props.onAfterSave) {
                this.props.onAfterSave();
            }
        });
    }
    private _onRenderSyncIcon = () => {
        return <Spinner size={SpinnerSize.small} />;
    }
    render() {
        const syncing = this.props.listing.saveSync.syncing;
        return (
            <PrimaryButton className="action save-action" onClick={this._onClick} iconProps={syncing ? undefined : { iconName: "Save" }} onRenderIcon={syncing ? this._onRenderSyncIcon : undefined} disabled={syncing}>
                {syncing ? "Saving..." : "Save"}
            </PrimaryButton>
        );
    }
}

@observer
class AppletListingCancelAction extends React.Component<IAppletListingProps, any> {
    render() {
        if(this.props.onCancel) {
            return <DefaultButton className="action cancel-action" onClick={this.props.onCancel} disabled={this.props.listing.saveSync.syncing}>Cancel</DefaultButton>;
        }
        return null;
    }
}

class AppletListingActions extends React.Component<IAppletListingProps, any> {
    render() {
        return (
            <div className={css(ClassNames.actions, "applet-listing-actions")}>
                <AppletListingCancelAction {...this.props} />
                <AppletListingSaveAction {...this.props} />
            </div>
        );
    }
}

@observer
class AppletListingSaveSync extends React.Component<IAppletListingProps, any> {
    render() {
        if(this.props.listing.saveSync.error) {
            return (
                <MessageBar messageBarType={MessageBarType.error}>
                    Unable to save listing - {this.props.listing.saveSync.error.message}
                </MessageBar>
            );
        }
        return null;
    }
}

class AppletListing extends React.Component<IAppletListingProps, any> {
    render() {
        return (
            <div className={css(ClassNames.root, "applet-listing")}>
                <AppletListingSaveSync {...this.props} />
                <AppletListingEditor {...this.props} />
                <AppletListingActions {...this.props} />
            </div>
        );
    }
}

interface IAppletListingContainerProps {
    listingHandle: ISyncHandle<IAppletListingModel>;
    onAfterSave?: () => void;
    onCancel?: () => void;
}

class AppletListingContainer extends React.Component<IAppletListingContainerProps, any> {
    private _onRenderDone = () => {
        return <AppletListing listing={this.props.listingHandle.value} onCancel={this.props.onCancel} onAfterSave={this.props.onAfterSave} />;
    }
    render() {
        return <SyncContainer sync={this.props.listingHandle.sync} onRenderDone={this._onRenderDone} />
    }
}

interface IAppletListingAppletProps extends IAppletProps {
    listingId: string;
}

class AppletListingApplet extends React.Component<IAppletListingAppletProps, any> {
    private _onCancel = () => {
        this.props.host.load({ path: "/listings" });
    }
    private _onAfterSave = () => {
        this.props.host.load({ path: "/listings" });
    }
    render() {
        return (
            <AppHostWrapper host={this.props.host} title="Applet Listing Details">
                <AppletListingContainer listingHandle={findById(this.props.listingId)} onCancel={this._onCancel} onAfterSave={this._onAfterSave} />
            </AppHostWrapper>
        );
    }
}

interface IAppletListingListProps {
    listings: IAppletListingListModel;
    onSelectItem?: (item : IAppletListing) => void;
}

@observer
class AppletListingList extends React.Component<IAppletListingListProps, any> {
    
    render() {
        return <AppletSelector items={this.props.listings.itemsView} onSelectItem={this.props.onSelectItem} />;
    }
}

class AppletListingListContainer extends React.Component<IAppletListingListProps, any> {
    componentWillMount() {
        this.props.listings.load();
    }
    private _onRenderDone = () => {
        return <AppletListingList {...this.props} />;
    }
    render() {
        return <SyncContainer sync={this.props.listings.sync} onRenderDone={this._onRenderDone} syncLabel="Loading Listings..." />
    }
}

class AppletListingListApplet extends React.Component<IAppletProps, any> {
    private _listings = new AppletListingListModel();
    private _onSelectItem = (item : IAppletListing) => {
        this.props.host.load({ path: `/listings/${encodeURIComponent(item.id)}`});
    }
    componentWillMount() {
        // we deliberately refresh here
        this._listings.refresh();
    }
    render() {
        return (
            <AppHostWrapper host={this.props.host} title="Applet Listings" className={css(ClassNames.applet, "applet-listing-list-applet")}>
                <AppletListingListContainer listings={this._listings} onSelectItem={this._onSelectItem} />
            </AppHostWrapper>
        );
    }
}

export {
    AppletListingListApplet,
    AppletListingApplet
}