import * as React from "react";
import IAppletListing from "listing/IAppletListing";
import { List } from "office-ui-fabric-react/lib/List";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import AppContainer from "app/component/AppContainer";
import "./AppletSelector.scss";

interface IAppletSelectorProps {
    items: IAppletListing[];
    onSelectItem?: (item : IAppletListing) => void;
}

interface IAppletItemProps {
    item: IAppletListing;
    onClick?: (item : IAppletListing) => void;
}

class AppletItem extends React.Component<IAppletItemProps, any> {
    private _onClick = () => {
        this.props.onClick(this.props.item);
    }
    private _onRenderBannerError = () => {
        return <Icon iconName="Puzzle" />;
    }
    render() {
        const bannerPath = `${this.props.item.path}/banner`;
        return (
            <div className="applet-item" onClick={this.props.onClick ? this._onClick : undefined} title={this.props.item.title}>
                <div className="applet-header">
                    <div className="applet-title">{this.props.item.title}</div>
                </div>
                <div className="applet-body">
                    <AppContainer path={bannerPath} params={{ width: 120, height: 78 }} onRenderError={this._onRenderBannerError} />
                </div>
            </div>
        )
    }
}

class AppletSelector extends React.Component<IAppletSelectorProps, any> {
    private _onRenderItem = (item, idx) => {
        return <AppletItem key={item.id} item={item} onClick={this.props.onSelectItem} />;
    }
    render() {
        return (
            <div className="applet-selector">
                <div className="applet-selector-header">
                </div>
                <div className="applet-selector-body">
                    <div className="applet-selector-items">
                        {this.props.items.map((item, idx) => this._onRenderItem(item, idx))}
                    </div>
                </div>
            </div>
        );
    }
}

export { AppletSelector as default, AppletSelector }