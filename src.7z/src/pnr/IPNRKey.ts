interface IPNRKey {
    bookingSystemCode?: string;
    recordLocator?: string;
    pnrCreationTimestamp?: string;
}

export { IPNRKey as default, IPNRKey }