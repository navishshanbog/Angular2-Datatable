import IPNRKey from "./IPNRKey";

interface IPNROtherServiceInfo extends IPNRKey {

}

export { IPNROtherServiceInfo as default, IPNROtherServiceInfo }