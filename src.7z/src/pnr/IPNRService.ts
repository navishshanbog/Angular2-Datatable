import IPNRSearchRequest from "./IPNRSearchRequest";
import IPNRServiceResponse from "./IPNRServiceResponse";
import IPNRSearchResult from "./IPNRSearchResult";
import IPNRTicketPayment from "./IPNRTicketPayment";
import IPNRKey from "./IPNRKey";

interface IPNRService {
    searchPNR(request : IPNRSearchRequest) : Promise<IPNRServiceResponse<IPNRSearchResult>>;
    getPNRTicketPaymentDetails(key : IPNRKey) : Promise<IPNRServiceResponse<IPNRTicketPayment>>;
}

export { IPNRService as default, IPNRService }