interface IPNRServiceResponse<T> {
    data: T[];
}

export { IPNRServiceResponse as default, IPNRServiceResponse }