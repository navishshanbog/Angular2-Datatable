import IPNRService from "./IPNRService";
import IPNRServiceResponse from "./IPNRServiceResponse";
import IPNRSearchRequest from "./IPNRSearchRequest";
import IPNRSearchResult from "./IPNRSearchResult";
import IPNRTicketPayment from "./IPNRTicketPayment";
import IPNRKey from "./IPNRKey";
import * as DateUtils from "util/Date";

const createSearchResponse = (request : IPNRSearchRequest) => {
    return {
        data: [
            {
                "dateOfBirth": "19930929",
                "firstOLocalScheduledDate": "2017-08-01",
                "firstIRouteId": "QF162",
                "countryOfIssue": "KINGS LANDING",
                "documentFamilyName": "DRACARYS",
                "passengerTattoo": "0",
                "familyName": "Targaryen",
                "firstORouteId": "AA99",
                "givenName": "Daenerys ",
                "intentToTravelDate": "2017-08-01",
                "intentToEndTravelDate": "2017-08-21",
                "documentFreeText": "P/NZL/LH379628/NZL/29SEP93/F/13JAN19/Targaryen/Daenerys Khaleesi",
                "firstILocalPortCode": "SYD ",
                "recordLocator": "QC4Q6O",
                "firstIForeignPortCode": "WLG ",
                "givenNames": "Daenerys Khaleesi",
                "gender": "F",
                "firstOForeignPortCode": "BKK ",
                "bookingSystemCode": "1A",
                "pnrCreationTimestamp": "2017-07-02T12:27:00.000+11:00",
                "travelDocumentNbr": "LH379628",
                "firstOLocalPortCode": "SYD ",
                "firstILocalScheduledDate": "2017-08-21"
            },
            {
                "dateOfBirth": "19930929",
                "firstOLocalScheduledDate": "2017-08-21",
                "firstIRouteId": "QF162",
                "countryOfIssue": "KINGS LANDING",
                "documentFamilyName": "DRACARYS",
                "passengerTattoo": "2",
                "familyName": "Targaryen",
                "firstORouteId": "QF23",
                "givenName": "Daenerys ",
                "intentToTravelDate": "2017-08-21",
                "intentToEndTravelDate": "2017-09-13",
                "documentFreeText": "P/NZL/LH379628/NZL/29SEP93/F/13JAN19/Targaryen/Daenerys",
                "firstILocalPortCode": "SYD ",
                "recordLocator": "QC4Q6O",
                "firstIForeignPortCode": "WLG ",
                "givenNames": "Daenerys",
                "gender": "F",
                "firstOForeignPortCode": "BKK ",
                "bookingSystemCode": "1A",
                "pnrCreationTimestamp": "2017-07-29T12:27:00.000+11:00",
                "travelDocumentNbr": "LH379628",
                "firstOLocalPortCode": "SYD ",
                "firstILocalScheduledDate": "2017-08-21"
            }
        ]
    }
};

class MockPNRService implements IPNRService {
    searchPNRResponseFactory : (request : IPNRSearchRequest) => IPNRServiceResponse<IPNRSearchResult> = createSearchResponse;
    getPNRTicketPaymentDetailsResponseFactory : (key : IPNRKey) => IPNRServiceResponse<IPNRTicketPayment>;
    searchPNR(request : IPNRSearchRequest) : Promise<IPNRServiceResponse<IPNRSearchResult>> {
        return Promise.resolve(this.searchPNRResponseFactory(request));
    }
    getPNRTicketPaymentDetails(key : IPNRKey) : Promise<IPNRServiceResponse<IPNRTicketPayment>> {
        return null;
    }
}

export { MockPNRService as default, MockPNRService }