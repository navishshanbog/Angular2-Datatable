import * as React from "react";
import Router from "roota/lib/Router";
import UserGroup from "user/UserGroup";
import { exactPath } from "common/RouterUtils";
import { createAuthHandler } from "app/AuthHandler";

const r = new Router();
r.use(createAuthHandler(UserGroup.PNR_SEARCH));
r.use("/search/results", exactPath(req => {
    return import("./component/PNRSearchResultsApplet").then(m => {
        return <m.PNRSearchResultsApplet host={req.app} />;
    });
}));
r.use("/search", exactPath(req => {
    return import("./component/PNRSearchApplet").then(m => {
        return <m.PNRSearchApplet host={req.app} />
    });
}));

export { r as default, r as PNRRouter }