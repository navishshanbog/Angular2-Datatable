import { action } from "mobx";
import IAppHost from "app/IAppHost";
import IPNRSearchRequest from "./IPNRSearchRequest";
import PNRSearchHistoryStore from "./PNRSearchHistoryStore";

const loadSearch = action((host : IAppHost) => {
    host.load({ path: "/pnr/search" });
});

const submitRequest = action((host : IAppHost, request : IPNRSearchRequest) => {
    // clear any search results or details on the host
    clearSearchResults(host);
    PNRSearchHistoryStore.addEntry(request);
    host.load({ path: "/pnr/search/results", params: { searchRequest: request } });
});

const loadSearchResults = action((host : IAppHost) => {
    host.load({ path: "/pnr/search/results" });
});

const clearSearchResults = action((host : IAppHost) => {
    host.setState({ pnrSearchResults: null, pnrSearchResult: null });
});

export {
    loadSearch,
    submitRequest,
    loadSearchResults,
    clearSearchResults
}