import Context from "common/Context";
import IPNRService from "./IPNRService";
import RestPNRDataService from "./RestPNRDataService";

const PNRServiceContext = new Context<IPNRService>({
    factory() {
        return new RestPNRDataService();
    }
});

export { PNRServiceContext as default, PNRServiceContext }