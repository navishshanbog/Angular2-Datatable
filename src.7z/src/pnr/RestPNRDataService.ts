import IPNRService from "./IPNRService";
import IPNRKey from "./IPNRKey";
import IPNRSearchRequest from "./IPNRSearchRequest";
import IPNRServiceResponse from "./IPNRServiceResponse";
import IPNRSearchResult from "./IPNRSearchResult";
import IPNRTicketPayment from "./IPNRTicketPayment";
import IUrlConfig from "config/IUrlConfig";
import RestDataServicePNRConfig from "config/RestDataServicePNRConfig";
import axios from "axios";
import * as DefaultHttpErrorHandler from "common/HttpErrorHandler";

interface IDSPNRKeyRequest {
    p_bookingSystemCode: string;
	p_recordLocator: string;
	p_pnrCreationTimestamp: string;
}

interface IDSPNRSearchRequest {
    p_RecLocator?: string;
    p_BookingSysCode?: string;
    p_FamilyName?: string;
    p_GivenName?: string;
    p_DateOfBirth?: string;
    p_AgeFrom?: string;
    p_AgeTo?: string;
    p_PnrCreationTSFrom?: string;
    p_PnrCreationTSTo?: string;
    p_TravelDocID?: string;
    p_TravelDocCountryCode?: string;
    p_ArrivalDateFrom?: string;
    p_ArrivalDateTo?: string;
    p_DepartureDateFrom?: string;
    p_DepartureDateTo?: string;
    p_OriginCityPort?: string;
    p_OriginRouteID?: string;
    p_DestinationPort?: string;
    p_DesitinationRouteID?: string; // NOTE: deliberate typo matching ds schema - will probably be fixed
    p_ArrivalCarrier?: string;
    p_DepartureCarrier?: string;
}

interface IDSPNRSearchResult {
    dateOfBirth?: string;
    firstOLocalScheduledDate?: string;
    firstIRouteId?: string;
    countryOfIssue?: string;
    documentFamilyName?: string;
    passengerTattoo?: string;
    familyName?: string;
    firstORouteId?: string;
    givenName?: string;
    intentToTravelDate?: string;
    intentToEndTravelDate?: string;
    documentFreeText?: string;
    firstILocalPortCode?: string;
    recordLocator?: string;
    firstIForeignPortCode?: string;
    givenNames?: string;
    gender?: string;
    firstOForeignPortCode?: string;
    bookingSystemCode?: string;
    pnrCreationTimestamp?: string;
    travelDocumentNbr?: string;
    firstOLocalPortCode?: string;
    firstILocalScheduledDate?: string;
}

interface IDSPNRSearchResults {
    data?: IPNRSearchResult[];
}

interface IDSPNRSearchResponse {
    getPnrMasterSearch?: IDSPNRSearchResults;
}

const mapSearchRequest = (request : IPNRSearchRequest) : IDSPNRSearchRequest => {
    if(request) {
        const r : IDSPNRSearchRequest = {};
        r.p_AgeFrom = !isNaN(request.ageFrom) ? String(request.ageFrom) : undefined;
        r.p_AgeTo = !isNaN(request.ageTo) ? String(request.ageTo) : undefined;
        r.p_ArrivalCarrier = request.arrivalCarrier;
        r.p_ArrivalDateFrom = request.arrivalDateFrom;
        r.p_ArrivalDateTo = request.arrivalDateTo;
        r.p_DateOfBirth = request.dateOfBirth;
        r.p_DepartureCarrier = request.departureCarrier;
        r.p_DepartureDateFrom = request.departureDateFrom;
        r.p_DepartureDateTo = request.departureDateTo;
        r.p_DesitinationRouteID = request.destinationRouteId;
        r.p_DestinationPort = request.destinationPort;
        r.p_FamilyName = request.familyName;
        r.p_GivenName = request.givenName;
        r.p_OriginCityPort = request.originCityPort;
        r.p_OriginRouteID = request.originRouteId;
        r.p_BookingSysCode = request.bookingSystemCode;
        r.p_PnrCreationTSFrom = request.pnrCreationTimestampFrom;
        r.p_PnrCreationTSTo = request.pnrCreationTimestampTo;
        r.p_RecLocator = request.recordLocator;
        r.p_TravelDocCountryCode = request.travelDocCountryCode;
        r.p_TravelDocID = request.travelDocId;
        return r;
    }
};

const mapSearchResponse = (response : IDSPNRSearchResponse) : IPNRServiceResponse<IPNRSearchResult> => {
    if(response && response.getPnrMasterSearch) {
        const r : IPNRServiceResponse<IPNRSearchResult> = { data: [] };
        const data = response.getPnrMasterSearch.data;
        if(data && data.length > 0) {
            data.forEach(item => {
                if(item) {
                    r.data.push(item);
                }
            });
        }
        return r;
    }
};

const mapKeyRequest = (key : IPNRKey) : IDSPNRKeyRequest => {
    return {
        p_bookingSystemCode: key.bookingSystemCode,
        p_recordLocator: key.recordLocator,
        p_pnrCreationTimestamp: key.pnrCreationTimestamp
    };
};

class DataServiceRestPNRService implements IPNRService {
    private _config : IUrlConfig;
    get config() : IUrlConfig {
        return this._config || RestDataServicePNRConfig;
    }
    set config(value) {
        this._config = value;
    }
    searchPNR(request : IPNRSearchRequest) : Promise<IPNRServiceResponse<IPNRSearchResult>> {
        const restRequest = mapSearchRequest(request);
        return axios.post(`${this.config.baseUrl}/resources/getPNRMasterSearch`, restRequest).then((value) => {
            const response =  value.data as IDSPNRSearchResponse;
            return mapSearchResponse(response);
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
    getPNRTicketPaymentDetails(key : IPNRKey) : Promise<IPNRServiceResponse<IPNRTicketPayment>> {
        const restRequest = mapKeyRequest(key);
        // TODO
        return null;
    }
}

export { DataServiceRestPNRService as default, DataServiceRestPNRService }