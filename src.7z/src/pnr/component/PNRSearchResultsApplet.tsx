import * as React from "react";
import { observer } from "mobx-react";
import IAppletProps from "app/component/IAppletProps";
import AppHostWrapper from "app/component/AppHostWrapper";
import PNRSearchResultsModel from "../PNRSearchResultsModel";
import IPNRSearchRequest from "../IPNRSearchRequest";
import { submitRequest } from "../PNRSearchActions";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { loadSearch } from "../PNRSearchActions";
import { PNRSearchResultsContainer } from "./PNRSearchResults";
import { ClassNames } from "./PNRSearchResultsApplet.style";
import { css } from "office-ui-fabric-react/lib/Utilities";

@observer
class PNRSearchResultsCommandBar extends React.Component<IAppletProps, any> {
    private _onClickBackToSearch = () => {
        loadSearch(this.props.host);
    }
    render() {
        const items : IContextualMenuItem[] = [
            {
                key: "backToSearch",
                name: "Search",
                title: "Back to Search",
                iconProps: { iconName: "Back" },
                onClick: this._onClickBackToSearch
            }
        ];
        return <CommandBar className="pnr-search-results-command-bar" items={items} />;
    }
}

class PNRSearchResultsApplet extends React.Component<IAppletProps, any> {
    get searchResults() {
        let r = this.props.host.state.pnrSearchResults;
        if(!r) {
            r = new PNRSearchResultsModel();
            this.props.host.setState({ pnrSearchResults: r });
        }
        return r;
    }
    componentWillMount() {
        this.props.host.setTitle("PNR Search Results");
        const searchRequest = this.props.host.params.searchRequest;
        if(searchRequest && searchRequest !== this.searchResults.request) {
            this.searchResults.search(searchRequest);
        }
    }
    render() {
        return (
            <AppHostWrapper host={this.props.host} className={css(ClassNames.root, "pnr-search-results-applet")} title="PNR Search Results">
                <div className={css(ClassNames.header, "pnr-search-results-applet-header")}>
                    <PNRSearchResultsCommandBar {...this.props} />
                </div>
                <div className={css(ClassNames.body, "pnr-search-results-applet-body")}>
                    <PNRSearchResultsContainer results={this.searchResults} />
                </div>
            </AppHostWrapper>
        );
    }
}

export { PNRSearchResultsApplet as default, PNRSearchResultsApplet }