interface ISearchRequestModel {
    text: string;
    setText(text : string) : void;
}

export { ISearchRequestModel as default, ISearchRequestModel }