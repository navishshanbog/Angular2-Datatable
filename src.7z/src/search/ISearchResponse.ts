interface ISearchResponse {
    total?: number;
    offset?: number;
    items: any[];
}

export { ISearchResponse as default, ISearchResponse }