import SearchModel from "./SearchModel";

const SearchStore = new SearchModel();
SearchStore.addCoreById("Cargo_IAir_CR_Line", "Air Cargo");
SearchStore.addCoreById("Cargo_ISea_CR_Line", "Sea Cargo");
SearchStore.addCoreById("Mail", "Mail");
SearchStore.addCoreById("PNR", "PNR");
SearchStore.addCoreById("NIS", "NIS");

export { SearchStore as default, SearchStore }