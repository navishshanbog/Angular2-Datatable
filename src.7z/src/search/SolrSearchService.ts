import ISearchService from "./ISearchService";
import ISearchRequest from "./ISearchRequest";
import ISearchResponse from "./ISearchResponse";
import IUrlConfig from "config/IUrlConfig";
import RestSolrConfig from "config/RestSolrConfig";
import { IQueryRequest } from "solr/RestClient";
import { runQuery } from "solr/DataServiceRestClient";
import * as StringUtils from "util/String";

const DEFAULT_PATH = "/demo/solrPOST/";

class SolrSearchService implements ISearchService {
    private _config : IUrlConfig;
    get config() : IUrlConfig {
        return this._config || RestSolrConfig;
    }
    set config(value) {
        this._config = value;
    }
    search(request : ISearchRequest) : Promise<ISearchResponse> {
        let query = request.text;
        if(StringUtils.isBlank(query)) {
            return Promise.resolve({
                total: 0,
                offset: 0,
                items: []
            });
        }
        
        const solrRequest : IQueryRequest = {
            q: query,
            start: request.offset !== undefined ? request.offset : undefined,
            rows: request.limit !== undefined ? request.limit : undefined,
            sort: request.sortBy ? `${request.sortBy} ${request.sortDescending ? "desc" : "asc"}` : undefined,
            wt: "json"
        };

        return runQuery(`${this.config.baseUrl}`, request.core, solrRequest).then(solrResponse => {
            return {
                total: solrResponse.response.numFound,
                offset: solrResponse.response.start,
                items: solrResponse.response.docs
            };
        });
    }
}

export { SolrSearchService as default, SolrSearchService }