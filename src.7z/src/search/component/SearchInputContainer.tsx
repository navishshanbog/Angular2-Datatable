import * as React from "react";
import { observer } from "mobx-react";
import { SearchBox, ISearchBox } from "office-ui-fabric-react/lib/SearchBox";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import ISearchRequestModel from "../ISearchRequestModel";
import ISearchRequest from "../ISearchRequest";
import * as StringUtils from "util/String";

interface ISearchInputProps {
    request : ISearchRequestModel;
    onSearch: (request : ISearchRequest) => void;
}

@observer
class SearchInputContainer extends React.Component<ISearchInputProps, any> {
    private _searchRef : ISearchBox;
    _handleChange = (text : string) => {
        this.props.request.setText(text);
    }
    _handleSearch = () => {
        if(StringUtils.isNotBlank(this.props.request.text)) {
            this.props.onSearch({ text: this.props.request.text });
        }
    }
    private _handleSearchRef = (ref : ISearchBox) => {
        this._searchRef = ref;
    }
    componentDidMount() {
        this._searchRef.focus();
    }
    render() {
        return (
            <div className="search-input-container">
                <SearchBox value={this.props.request.text || ""} ref={this._handleSearchRef} onChange={this._handleChange} onSearch={this._handleSearch} />
                <PrimaryButton onClick={this._handleSearch} iconProps={ { iconName: "Search" } } disabled={StringUtils.isBlank(this.props.request.text)}></PrimaryButton>
            </div>
        );
    }
}

export { SearchInputContainer as default, SearchInputContainer }