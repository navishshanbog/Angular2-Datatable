import axios from "axios";
import { IQueryRequest, IQueryCallResponse } from "./RestClient";

interface IDataServiceSolrQuery {
    params: IQueryRequest;
}

interface IDataServiceQueryRequest {
    server?: string;
    port?: string;
    core : string;
    solrQuery: IDataServiceSolrQuery;
}

const runQuery = (url : string, core : string, request : IQueryRequest) : Promise<IQueryCallResponse> => {
    const dsRequest : IDataServiceQueryRequest = {
        server: "",
        port: "",
        core: core,
        solrQuery: {
            params: request
        }
    };
    return axios.post(url, dsRequest).then((res) => {
        return res.data as IQueryCallResponse;
    });
};

export { IDataServiceQueryRequest, runQuery }